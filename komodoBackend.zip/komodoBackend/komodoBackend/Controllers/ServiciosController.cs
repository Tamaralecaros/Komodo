﻿using komodoBackend.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore; // ← importante para ToList() o EF Core

namespace komodoBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ServiciosController : ControllerBase
    {
        private readonly KomodoContext _context;

        public ServiciosController(KomodoContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetServicios()
        {
            var servicios = _context.Servicios.ToList();

            var lista = servicios.Select(s => new {
                id = s.id_servicio,
                nombre = s.nombre_servicio,
                descripcion = s.descripcion,
                precio = s.precio_referencial,
                categoria = s.categoria
            });

            return Ok(lista);
        }
    }
}
