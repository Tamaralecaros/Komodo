﻿using Microsoft.AspNetCore.Mvc;
using komodoBackend.Models;
using System.Security.Cryptography;
using System.Text;

namespace komodoBackend.Controllers
{
    [Route("[controller]")]
    public class AuthController : Controller
    {
        private readonly KomodoContext _context;

        public AuthController(KomodoContext context)
        {
            _context = context;
        }

        // ================================================
        // LOGIN con validación + manejo de errores
        // ================================================
        [HttpPost("Login")]
        public IActionResult Login([FromBody] LoginRequest req)
        {
            // Validación del body
            if (req == null)
            {
                return BadRequest(new { ok = false, msg = "Body vacío" });
            }

            if (string.IsNullOrEmpty(req.correo))
            {
                return BadRequest(new { ok = false, msg = "Correo no enviado" });
            }

            if (string.IsNullOrEmpty(req.contrasena))
            {
                return BadRequest(new { ok = false, msg = "Contraseña no enviada" });
            }

            // Buscar usuario
            var user = _context.Usuarios
                               .FirstOrDefault(u => u.correo == req.correo);

            if (user == null)
            {
                return Unauthorized(new { ok = false, msg = "Correo incorrecto" });
            }

            // Hash de la contraseña ingresada
            var hashed = HashPassword(req.contrasena);

            // Comparar con la contraseña guardada en BD
            if (user.contrasena != hashed)
            {
                return Unauthorized(new { ok = false, msg = "Contraseña incorrecta" });
            }

            // Respuesta final correcta
            return Ok(new
            {
                ok = true,
                id = user.id_usuario,
                nombre = user.nombre,
                rol = user.rol
            });
        }

        // ================================================
        // HASH seguro con validación
        // ================================================
        private string HashPassword(string pass)
        {
            if (string.IsNullOrEmpty(pass))
            {
                return null; // Evita reventar
            }

            using var sha = SHA256.Create();
            byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(pass));
            return Convert.ToBase64String(bytes);
        }
    }

    public class LoginRequest
    {
        public string correo { get; set; }
        public string contrasena { get; set; }
    }
}
