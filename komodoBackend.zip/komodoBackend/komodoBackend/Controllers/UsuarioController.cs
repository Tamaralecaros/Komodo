﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using komodoBackend.Models;
using System.Security.Cryptography;
using System.Text;

namespace komodoBackend.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        private readonly KomodoContext _context;

        public UsuarioController(KomodoContext context)
        {
            _context = context;
        }

        // =======================================================
        // POST /Usuario/Registrar
        // =======================================================
        [HttpPost("Registrar")]
        public async Task<IActionResult> Registrar([FromBody] RegistrarRequest req)
        {
            if (!ModelState.IsValid)
                return BadRequest(new { ok = false, msg = "Datos inválidos." });

            // Validar correo único
            var existe = await _context.Usuarios
                .AnyAsync(u => u.correo == req.correo);

            if (existe)
                return BadRequest(new { ok = false, msg = "El correo ya está registrado." });

            // Hash contraseña
            var hashed = HashPassword(req.contrasena);

            var nuevo = new Usuario
            {
                nombre = req.nombre,
                correo = req.correo,
                telefono = req.telefono,
                rol = "cliente",        // por defecto
                contrasena = hashed
            };

            _context.Usuarios.Add(nuevo);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                ok = true,
                msg = "Usuario registrado correctamente",
                id = nuevo.id_usuario
            });
        }

        // =======================================================
        // FUNCIÓN HASH
        // =======================================================
        private string HashPassword(string pass)
        {
            using var sha = SHA256.Create();
            byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(pass));
            return Convert.ToBase64String(bytes);
        }

        // =======================================================
        // DTO PARA OLVIDAR CONTRASEÑA
        // =======================================================
        public class OlvidarDTO
        {
            public string correo { get; set; }
        }

        // =======================================================
        // POST /Usuario/OlvidarPassword
        // =======================================================
        [HttpPost("OlvidarPassword")]
        public async Task<IActionResult> OlvidarPassword([FromBody] OlvidarDTO dto)
        {
            if (dto == null || string.IsNullOrEmpty(dto.correo))
                return BadRequest(new { message = "Debe enviar un correo." });

            var usuario = await _context.Usuarios
                .FirstOrDefaultAsync(u => u.correo == dto.correo);

            if (usuario == null)
                return NotFound(new { message = "No existe un usuario con ese correo" });

            // generar token
            var token = Guid.NewGuid().ToString();

            usuario.resetToken = token;
            usuario.tokenExpira = DateTime.Now.AddHours(1);

            await _context.SaveChangesAsync();

            return Ok(new { token });
        }

        // =======================================================
        // DTO PARA RESET PASSWORD
        // =======================================================
        public class ResetPasswordDTO
        {
            public string Token { get; set; }
            public string Password { get; set; }
        }

        // =======================================================
        // POST /Usuario/ResetPassword
        // =======================================================
        [HttpPost("ResetPassword")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordDTO dto)
        {
            if (dto == null || string.IsNullOrEmpty(dto.Token))
                return BadRequest(new { message = "Token inválido" });

            var usuario = await _context.Usuarios
                .FirstOrDefaultAsync(u => u.resetToken == dto.Token);

            if (usuario == null)
                return NotFound(new { message = "Token inválido" });

            if (usuario.tokenExpira < DateTime.Now)
                return BadRequest(new { message = "Token expirado" });

            // Guardar nueva contraseña hasheada
            usuario.contrasena = HashPassword(dto.Password);

            usuario.resetToken = null;
            usuario.tokenExpira = null;

            await _context.SaveChangesAsync();

            return Ok(new { message = "Contraseña actualizada" });
        }
    }

    // ===========================================================
    // DTO Registro
    // ===========================================================
    public class RegistrarRequest
    {
        public string nombre { get; set; }
        public string correo { get; set; }
        public string telefono { get; set; }
        public string contrasena { get; set; }
    }
}
