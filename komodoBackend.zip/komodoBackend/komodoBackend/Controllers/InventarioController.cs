﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using komodoBackend.Models;

namespace komodoBackend.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class InventarioController : ControllerBase
    {
        private readonly KomodoContext _context;

        public InventarioController(KomodoContext context)
        {
            _context = context;
        }

        // ============================
        // GET /Inventario/Lista
        // ============================
        [HttpGet("Lista")]
        public async Task<IActionResult> Lista()
        {
            // 1) Primero cargamos todo desde SQL tal cual
            var data = await _context.Inventarios.ToListAsync();

            // 2) Luego transformamos fuera del LINQ
            var resultado = data.Select(i => new
            {
                id = i.id_producto,
                name = i.nombre ?? "(sin nombre)",
                category = i.categoria ?? "",
                stock = i.cantidad ?? 0,
                min = i.stock_minimo,
                unit = i.unidad ?? "u",
                updated = (i.fecha_actualizacion ?? DateTime.Now)
                          .ToString("dd-MM-yyyy HH:mm")
            });

            return Ok(resultado);
        }

        // ============================
        // POST /Inventario/Crear
        // ============================
        public class CrearInventarioReq
        {
            public string name { get; set; }
            public string category { get; set; }
            public int stock { get; set; }
            public int min { get; set; }
            public string unit { get; set; }
        }

        [HttpPost("Crear")]
        public async Task<IActionResult> Crear([FromBody] CrearInventarioReq req)
        {
            var item = new Inventario
            {
                nombre = req.name,
                cantidad = req.stock,
                categoria = req.category,
                stock_minimo = req.min,
                unidad = req.unit,
                precio_unitario = 0,
                fecha_actualizacion = DateTime.Now
            };

            _context.Inventarios.Add(item);
            await _context.SaveChangesAsync();

            return Ok(new { ok = true, id = item.id_producto });
        }

        // ============================
        // PUT /Inventario/Editar/{id}
        // ============================
        [HttpPut("Editar/{id}")]
        public async Task<IActionResult> Editar(int id, [FromBody] CrearInventarioReq req)
        {
            var item = await _context.Inventarios.FindAsync(id);
            if (item == null) return NotFound();

            item.nombre = req.name;
            item.cantidad = req.stock;
            item.categoria = req.category;
            item.stock_minimo = req.min;
            item.unidad = req.unit;
            item.fecha_actualizacion = DateTime.Now;

            await _context.SaveChangesAsync();

            return Ok(new { ok = true });
        }

        // ============================
        // DELETE /Inventario/Eliminar/{id}
        // ============================
        [HttpDelete("Eliminar/{id}")]
        public async Task<IActionResult> Eliminar(int id)
        {
            var item = await _context.Inventarios.FindAsync(id);
            if (item == null) return NotFound();

            _context.Inventarios.Remove(item);
            await _context.SaveChangesAsync();

            return Ok(new { ok = true });
        }
    }
}
