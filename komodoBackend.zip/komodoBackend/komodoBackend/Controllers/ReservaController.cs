﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using komodoBackend.Models;

namespace komodoBackend.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ReservaController : ControllerBase
    {
        private readonly KomodoContext _context;

        public ReservaController(KomodoContext context)
        {
            _context = context;
        }

        // =====================================================
        // GET /Reserva/Todas
        // Genera: abono, total y saldo correctamente
        // =====================================================
        [HttpGet("Todas")]
        public async Task<IActionResult> Todas()
        {
            var lista = await _context.Citas
                .Include(c => c.Cliente)
                .Include(c => c.Servicio)
                .Select(c => new
                {
                    id = c.id_cita,
                    cliente = c.Cliente.nombre,
                    correo = c.Cliente.correo,
                    servicio = c.Servicio.nombre_servicio,

                    fechaISO = c.fecha,
                    hora = c.hora.ToString(),
                    estado = c.estado,

                    // ABONO REAL (si no hay, retorna 0)
                    abono = _context.Pagos
                        .Where(p => p.id_cita == c.id_cita)
                        .OrderBy(p => p.id_pago)
                        .Select(p => p.monto)
                        .FirstOrDefault(),

                    total = c.Servicio.precio_referencial,

                    saldo = c.Servicio.precio_referencial -
                            _context.Pagos
                                .Where(p => p.id_cita == c.id_cita)
                                .OrderBy(p => p.id_pago)
                                .Select(p => p.monto)
                                .FirstOrDefault()
                })
                .ToListAsync();

            return Ok(lista);
        }


        // =====================================================
        // FINALIZAR — genera solo el saldo como pago
        // =====================================================
        public class FinalizarRequest
        {
            public int id_cita { get; set; }
            public decimal total { get; set; }  // total del servicio
        }

        [HttpPost("Finalizar")]
        public async Task<IActionResult> Finalizar([FromBody] FinalizarRequest req)
        {
            var cita = await _context.Citas
                .Include(c => c.Servicio)
                .FirstOrDefaultAsync(c => c.id_cita == req.id_cita);

            if (cita == null) return NotFound();

            // ABONO REAL pagado por Webpay
            var abono = await _context.Pagos
                .Where(p => p.id_cita == req.id_cita && p.tipo_pago == "Abono")
                .Select(p => p.monto)
                .FirstOrDefaultAsync();

            var saldo = req.total - abono;

            // Cambiar estado
            cita.estado = "finalizada";

            // Registrar pago SOLO del saldo (lo que faltaba)
            var pago = new Pago
            {
                id_cita = req.id_cita,
                monto = saldo,
                tipo_pago = "Caja",
                fecha_pago = DateTime.Now
            };

            _context.Pagos.Add(pago);
            await _context.SaveChangesAsync();

            return Ok(new { ok = true, comprobante = pago.id_pago });
        }

        // =====================================================
        // CANCELAR — admin puede cancelar
        // =====================================================
        [HttpPost("Cancelar/{id}")]
        public async Task<IActionResult> Cancelar(int id)
        {
            var cita = await _context.Citas
                .Include(c => c.Cliente)
                .FirstOrDefaultAsync(c => c.id_cita == id);

            if (cita == null) return NotFound();

            cita.estado = "cancelada";
            await _context.SaveChangesAsync();

            return Ok(new
            {
                ok = true,
                correo = cita.Cliente.correo,
                cliente = cita.Cliente.nombre
            });
        }

        // =====================================================
        // HORAS OCUPADAS PARA EL CALENDARIO
        // GET /Reserva/HorasOcupadas?fecha=2025-11-30
        // =====================================================
        [HttpGet("HorasOcupadas")]
        public async Task<IActionResult> HorasOcupadas([FromQuery] DateTime fecha)
        {
            var horas = await _context.Citas
                .Where(c =>
                    c.fecha == fecha &&
                    (c.estado == "reservada" || c.estado == "finalizada")
                )
                .Select(c => c.hora) // <-- aquí es TimeSpan normal
                .ToListAsync();

            // Convertir TimeSpan a "HH:mm"
            var lista = horas
                .Select(h => h.ToString(@"hh\:mm"))
                .ToList();

            return Ok(lista);
        }

    }
}
