﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using komodoBackend.Models;

namespace komodoBackend.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class IngresosController : ControllerBase
    {
        private readonly KomodoContext _context;

        public IngresosController(KomodoContext context)
        {
            _context = context;
        }

        // ============================
        // 1) RESUMEN
        // ============================
        [HttpGet("Resumen")]
        public IActionResult Resumen()
        {
            DateTime hoy = DateTime.Today;
            DateTime inicioSemana = hoy.AddDays(-(int)hoy.DayOfWeek + 1);
            DateTime inicioMes = new DateTime(hoy.Year, hoy.Month, 1);

            decimal totalHoy = _context.Pagos
                .Where(p => p.fecha_pago.HasValue && p.fecha_pago.Value.Date == hoy)
                .Sum(p => (decimal?)p.monto) ?? 0;

            decimal totalSemana = _context.Pagos
                .Where(p => p.fecha_pago.HasValue && p.fecha_pago.Value.Date >= inicioSemana)
                .Sum(p => (decimal?)p.monto) ?? 0;

            decimal totalMes = _context.Pagos
                .Where(p => p.fecha_pago.HasValue && p.fecha_pago.Value.Date >= inicioMes)
                .Sum(p => (decimal?)p.monto) ?? 0;

            decimal totalGeneral = _context.Pagos.Sum(p => (decimal?)p.monto) ?? 0;

            return Ok(new
            {
                hoy = totalHoy,
                semana = totalSemana,
                mes = totalMes,
                total = totalGeneral,

                hoyCount = _context.Pagos.Count(p => p.fecha_pago.HasValue && p.fecha_pago.Value.Date == hoy),
                semanaCount = _context.Pagos.Count(p => p.fecha_pago.HasValue && p.fecha_pago.Value.Date >= inicioSemana),
                mesCount = _context.Pagos.Count(p => p.fecha_pago.HasValue && p.fecha_pago.Value.Date >= inicioMes),
                totalCount = _context.Pagos.Count()
            });
        }

        // ============================
        // 2) ÚLTIMOS MOVIMIENTOS
        // ============================
        [HttpGet("Movimientos")]
        public IActionResult Movimientos()
        {
            var movs = _context.Pagos
                .Include(p => p.Cita)
                    .ThenInclude(c => c.Cliente)
                .Include(p => p.Cita.Servicio)
                .OrderByDescending(p => p.fecha_pago)
                .Take(30)
                .Select(p => new
                {
                    fecha = p.fecha_pago,
                    monto = p.monto,
                    metodo = p.tipo_pago,
                    servicio = p.Cita.Servicio.nombre_servicio,
                    cliente = p.Cita.Cliente.nombre
                })
                .ToList();

            return Ok(movs);
        }
    }
}
