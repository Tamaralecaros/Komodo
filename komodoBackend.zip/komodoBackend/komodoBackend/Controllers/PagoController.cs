﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Text;
using komodoBackend.Models;

namespace komodoBackend.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class PagoController : ControllerBase
    {
        private readonly KomodoContext _context;
        private readonly HttpClient _http;

        public PagoController(KomodoContext context)
        {
            _context = context;

            _http = new HttpClient();
            _http.DefaultRequestHeaders.Clear();

            // CREDENCIALES OFICIALES WEBPAY PLUS SANDBOX
            _http.DefaultRequestHeaders.Add("Tbk-Api-Key-Id", "597055555532");
            _http.DefaultRequestHeaders.Add("Tbk-Api-Key-Secret", "579B532A7440BB0C9079DED94D31EA1615BACEB56610332264630D42D0A36B1C");

        }

        public class PagoInitRequest
        {
            public int idServicio { get; set; }
            public string fecha { get; set; }
            public string hora { get; set; }
            public int idCliente { get; set; }
        }

        // ======================================================
        // 1) INICIAR TRANSACCIÓN
        // ======================================================
        [HttpPost("IniciarPago")]
        public async Task<IActionResult> IniciarPago([FromBody] PagoInitRequest req)
        {
            HttpContext.Session.SetInt32("idServicio", req.idServicio);
            HttpContext.Session.SetString("fecha", req.fecha);
            HttpContext.Session.SetString("hora", req.hora);
            HttpContext.Session.SetInt32("idCliente", req.idCliente);

            var body = new
            {
                buy_order = Guid.NewGuid().ToString().Substring(0, 12),
                session_id = HttpContext.Session.Id,
                amount = 1000, 
                return_url = "https://localhost:7216/Pago/Confirmar"
            };

            string json = JsonSerializer.Serialize(body);

            var request = new HttpRequestMessage(
                HttpMethod.Post,
                "https://webpay3gint.transbank.cl/rswebpaytransaction/api/webpay/v1.2/transactions"
            );

            request.Content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _http.SendAsync(request);
            var responseText = await response.Content.ReadAsStringAsync();

            Console.WriteLine("WEBPAY RESPUESTA:");
            Console.WriteLine(responseText);

            if (!response.IsSuccessStatusCode)
            {
                return BadRequest(new
                {
                    ok = false,
                    mensaje = "Transbank rechazó la transacción",
                    detalle = responseText
                });
            }

            var data = JsonSerializer.Deserialize<WebpayInitResponse>(responseText);

            return Ok(new { token = data.token, url = data.url });
        }

        // ======================================================
        // 2) CONFIRMACIÓN
        // ======================================================
        [HttpGet("Confirmar")]
        public async Task<IActionResult> Confirmar(string token_ws)
        {
            var response = await _http.PutAsync(
                $"https://webpay3gint.transbank.cl/rswebpaytransaction/api/webpay/v1.2/transactions/{token_ws}",
                null
            );

            var json = await response.Content.ReadAsStringAsync();
            var data = JsonSerializer.Deserialize<WebpayConfirmResponse>(json);

            Console.WriteLine("CONFIRMAR WEBPAY:");
            Console.WriteLine(json);

            if (data.status == "AUTHORIZED")
            {
                await GuardarPagoYCita(data);
                return Redirect("/Komodo/exito.html");
            }

            return Redirect("/Komodo/error.html");
        }

        // ======================================================
        // 3) GUARDAR BD
        // ======================================================
        private async Task GuardarPagoYCita(WebpayConfirmResponse data)
        {
            int idServicio = HttpContext.Session.GetInt32("idServicio").Value;
            int idCliente = HttpContext.Session.GetInt32("idCliente").Value;
            DateTime fecha = DateTime.Parse(HttpContext.Session.GetString("fecha"));
            TimeSpan hora = TimeSpan.Parse(HttpContext.Session.GetString("hora"));

            var cita = new Cita
            {
                id_cliente = idCliente,
                id_servicio = idServicio,
                fecha = fecha,
                hora = hora,
                estado = "confirmada"
            };

            _context.Citas.Add(cita);
            await _context.SaveChangesAsync();

            var pago = new Pago
            {
                id_cita = cita.id_cita,
                tipo_pago = "Abono",
                monto = 1000,
                fecha_pago = DateTime.Now
            };

            _context.Pagos.Add(pago);
            await _context.SaveChangesAsync();
        }
    }

    // MODELOS
    public class WebpayInitResponse
    {
        public string token { get; set; }
        public string url { get; set; }
    }

    public class WebpayConfirmResponse
    {
        public string status { get; set; }
        public string buy_order { get; set; }
        public string authorization_code { get; set; }
        public string transaction_date { get; set; }
    }
}
