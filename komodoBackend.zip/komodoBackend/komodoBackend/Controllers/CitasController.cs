﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using komodoBackend.Models;

namespace komodoBackend.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class CitasController : ControllerBase
    {
        private readonly KomodoContext _context;

        public CitasController(KomodoContext context)
        {
            _context = context;
        }

        // ---------------------------------------------
        // GET /Citas/MisCitasData (citas del usuario)
        // ---------------------------------------------
        [HttpGet("MisCitasData/{idCliente}")]
        public IActionResult MisCitasData(int idCliente)
        {
            var citas = _context.Citas
                .Where(c => c.id_cliente == idCliente)
                .Include(c => c.Servicio)
                .OrderBy(c => c.fecha)
                .Select(c => new
                {
                    servicio = c.Servicio.nombre_servicio,
                    fecha = c.fecha.ToString("dd/MM/yyyy"),
                    hora = c.hora,
                    estado = c.estado
                })
                .ToList();

            return Ok(citas);
        }

    }
}
