﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using komodoBackend.Models;

namespace komodoBackend.Controllers
{
    [Route("Solicitud_Compra")]
    [ApiController]
    public class Solicitud_CompraController : ControllerBase
    {
        private readonly KomodoContext _context;

        public Solicitud_CompraController(KomodoContext context)
        {
            _context = context;
        }

        // ======================================================
        // GET /Solicitud_Compra/Lista
        // ======================================================
        [HttpGet("Lista")]
        public async Task<IActionResult> Lista()
        {
            var lista = await (
                from s in _context.SolicitudesCompra
                join p in _context.Inventarios on s.id_producto equals p.id_producto
                join u in _context.Usuarios on s.id_peluquero equals u.id_usuario
                select new
                {
                    id = s.id_solicitud,
                    fecha = s.fecha_solicitud.ToString("dd-MM-yyyy HH:mm"),
                    producto = p.nombre,
                    peluquero = u.nombre,
                    cantidad = s.cantidad,
                    nota = s.nota,
                    estado = s.estado
                }
            ).ToListAsync();

            return Ok(lista);
        }

        // ======================================================
        // POST /Solicitud_Compra/Crear
        // ======================================================
        public class CrearSolicitudReq
        {
            public int id_producto { get; set; }
            public int cantidad { get; set; }
            public string nota { get; set; }
            public string usuario { get; set; }
        }

        [HttpPost("Crear")]
        public async Task<IActionResult> Crear([FromBody] CrearSolicitudReq req)
        {
            // Buscar id del peluquero según nombre de usuario
            var peluquero = await _context.Usuarios
                .FirstOrDefaultAsync(u => u.nombre == req.usuario);

            int idPeluqueroFinal = peluquero?.id_usuario ?? 1; // fallback temporal

            var sol = new Solicitud_Compra
            {
                id_producto = req.id_producto,
                cantidad = req.cantidad,
                nota = req.nota,
                fecha_solicitud = DateTime.Now,
                estado = "pendiente",
                id_peluquero = idPeluqueroFinal
            };

            _context.SolicitudesCompra.Add(sol);
            await _context.SaveChangesAsync();

            return Ok(new { ok = true, id = sol.id_solicitud });
        }

        // ======================================================
        // POST /Solicitud_Compra/ActualizarEstado/{id}
        // ======================================================
        [HttpPost("ActualizarEstado/{id}")]
        public async Task<IActionResult> ActualizarEstado(int id, [FromBody] string nuevoEstado)
        {
            var sol = await _context.SolicitudesCompra.FindAsync(id);
            if (sol == null) return NotFound();

            sol.estado = nuevoEstado;
            await _context.SaveChangesAsync();

            return Ok(new { ok = true });
        }
    }
}
