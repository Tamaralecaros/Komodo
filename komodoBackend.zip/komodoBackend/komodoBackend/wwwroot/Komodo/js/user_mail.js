﻿// Enviar correo de bienvenida
export function enviarBienvenida(nombre, correo) {

    const params = {
        to_name: nombre,
        mensaje: `Hola ${nombre}, tu cuenta ha sido creada correctamente en KÓMODO. 
        Ya puedes iniciar sesión y gestionar tus servicios.`
    };

    return emailjs.send("service_123", "template_ovywtnl", params, "wJn2iMQKwXdMDtvqH");
}

// Enviar correo de recuperación de contraseña
export function enviarRecuperacion(nombre, correo, link) {

    const params = {
        to_name: nombre,
        mensaje: `Hola ${nombre}, para restablecer tu contraseña haz clic aquí:\n${link}`
    };

    return emailjs.send("service_123", "template_ovywtnl", params, "wJn2iMQKwXdMDtvqH");
}
