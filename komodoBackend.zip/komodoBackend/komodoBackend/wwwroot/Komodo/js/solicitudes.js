﻿// ===============================
// solicitudes.js  — KÓMODO
// ===============================

const API = "https://localhost:7216/Solicitud_Compra";
const $ = (s, c = document) => c.querySelector(s);

// ===============================
// Cargar solicitudes
// ===============================
async function cargarSolicitudes() {
    try {
        const res = await fetch(`${API}/Lista`);
        const data = await res.json();

        console.log("Solicitudes:", data);

        const tbody = $("#tbl_solicitudes tbody");
        tbody.innerHTML = "";

        if (!data.length) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="muted">No hay solicitudes registradas.</td>
                </tr>`;
            return;
        }

        data.forEach(s => {

            const tr = document.createElement("tr");

            // Formatear fecha
            const fechaTxt = s.fecha.split(" ")[0];

            // Mostrar botones solo si está pendiente
            let botones = "";

            if (s.estado === "pendiente") {
                botones = `
        <div class="k-actions">
            <button class="k-btn k-btn--ok" onclick="actualizarEstado(${s.id}, 'aprobada')">Aprobar</button>
            <button class="k-btn k-btn--danger" onclick="actualizarEstado(${s.id}, 'rechazada')">Rechazar</button>
        </div>
    `;
            }
            else if (s.estado === "aprobada") {
                botones = `<span class="estado-confirmado">Confirmado</span>`;
            }
            else if (s.estado === "rechazada") {
                botones = `<span class="estado-rechazado">Rechazado</span>`;
            }


            tr.innerHTML = `
                <td>${fechaTxt}</td>
                <td>${s.peluquero}</td>
                <td>
                    <strong>${s.producto}</strong><br>
                    <small>Cant: ${s.cantidad} — Nota: ${s.nota || "-"}</small>
                </td>
                <td>${s.estado}</td>
                <td>${botones}</td>
            `;

            tbody.appendChild(tr);
        });

    } catch (err) {
        console.error("Error al cargar solicitudes:", err);
    }
}

// ===============================
// Cambiar estado
// ===============================
async function actualizarEstado(id, estado) {
    const res = await fetch(`${API}/ActualizarEstado/${id}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(estado)
    });

    const data = await res.json();

    if (data.ok) {
        alert(`Solicitud ${estado}`);
        cargarSolicitudes();
    }
}

document.addEventListener("DOMContentLoaded", cargarSolicitudes);
