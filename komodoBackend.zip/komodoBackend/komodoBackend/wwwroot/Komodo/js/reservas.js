// ==========================================
// RESERVAS.JS — Módulo de administración
// ==========================================

import { getRole } from "/Komodo/js/roles.js";

const API = "https://localhost:7216/Reserva";

// =======================
// Formato de hora chilena
// =======================
function formatearHoraChilena(horaSQL) {
    if (!horaSQL) return "-";
    return `${horaSQL.substring(0, 5)} hrs`;
}

// =======================
// Estado amigable
// =======================
function formatearEstado(estado) {
    switch (estado) {
        case "confirmada": return "Confirmada";
        case "finalizada": return "Finalizada";
        case "cancelada": return "Cancelada";
        default: return estado;
    }
}

// =======================
// Cargar reservas
// =======================
async function cargarReservas() {
    try {
        const res = await fetch(`${API}/Todas`);
        if (!res.ok) {
            console.error("HTTP ERROR:", res.status);
            alert("No se pudo obtener reservas.");
            return;
        }

        const data = await res.json();
        const tbody = document.querySelector("#tbody_reservas");
        tbody.innerHTML = "";

        data.forEach(r => {
            const fecha = r.fechaISO.split("T")[0];
            const hora = formatearHoraChilena(r.hora);

            const tr = document.createElement("tr");

            tr.innerHTML = `
                <td>${r.id}</td>
                <td>${r.cliente}</td>
                <td>${r.servicio}</td>
                <td>${fecha}</td>
                <td>${hora}</td>
                <td>${formatearEstado(r.estado)}</td>
                <td class="ta-r">$${r.abono}</td>
                <td class="ta-r">$${r.saldo}</td>
                <td class="ta-r">$${r.total}</td>
                <td>${renderBotones(r)}</td>
            `;

            tbody.appendChild(tr);
        });

    } catch (err) {
        console.error("Error al cargar reservas:", err);
        alert("Error al conectar con el backend.");
    }
}

// =======================
// Render de botones
// =======================
function renderBotones(r) {
    const rol = getRole();

    // FINALIZADA o CANCELADA → solo etiqueta
    if (r.estado === "finalizada") {
        return `<span class="k-tag k-tag--gold">Finalizada</span>`;
    }

    if (r.estado === "cancelada") {
        return `<span class="k-tag k-tag--danger">Cancelada</span>`;
    }

    // TRABAJADOR — solo puede finalizar
    if (rol === "trabajador") {
        return `
            <button class="k-btn k-btn--gold"
                onclick="finalizar(${r.id}, ${r.total})">Finalizar</button>
        `;
    }

    // ADMIN — también solo puede finalizar (cancelar eliminado)
    if (rol === "admin") {
        return `
            <button class="k-btn k-btn--gold"
                onclick="finalizar(${r.id}, ${r.total})">Finalizar</button>
        `;
    }

    return "-";
}

// =======================
// Finalizar reserva
// =======================
async function finalizar(id, total) {
    try {
        const res = await fetch(`${API}/Finalizar`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id_cita: id, total })
        });

        const data = await res.json();

        if (data.ok) {
            alert("Reserva finalizada correctamente.");
            cargarReservas();
        }

    } catch (err) {
        console.error("Error al finalizar:", err);
        alert("No se pudo finalizar la reserva.");
    }
}

// =======================
// Inicialización
// =======================
document.addEventListener("DOMContentLoaded", cargarReservas);

// =======================
// Exponer funciones al DOM
// =======================
window.finalizar = finalizar;
