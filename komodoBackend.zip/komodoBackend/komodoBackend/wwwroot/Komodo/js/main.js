/* =============================
   KÓMODO · MAIN.JS COMPLETO
============================= */

/* Footer: Año automático */
const y = document.getElementById("year");
if (y) y.textContent = new Date().getFullYear();

/* Abrir modal de autenticación */
const authModal = document.getElementById("authModal");
document.addEventListener("click", (e) => {
    const openAuth = e.target.closest("[data-open-auth]");
    if (openAuth) {
        e.preventDefault();
        authModal?.showModal();
    }
});

/* ======================================================
      LOGIN REAL CON BACKEND + ROLES REALES
====================================================== */

import { setSession, homeFor } from "/Komodo/js/roles.js";

document.addEventListener("DOMContentLoaded", () => {

    /* =============================
         LOGIN
    ============================= */
    const loginForm = document.getElementById("loginForm");

    if (loginForm) {
        const loginEmail = document.getElementById("loginEmail");
        const loginPass = document.getElementById("loginPass");
        const loginError = document.getElementById("loginError");

        loginForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            const correo = loginEmail.value.trim();
            const contrasena = loginPass.value;

            try {
                const res = await fetch("https://localhost:7216/Auth/Login", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ correo, contrasena })
                });

                const data = await res.json();

                if (!res.ok || !data.ok) {
                    loginError.style.display = "block";
                    return;
                }

                /* Guardar sesión real */
                setSession({
                    id: data.id,
                    nombre: data.nombre,
                    rol: data.rol.toLowerCase()
                });

                /* Redirigir según rol */
                window.location.href = homeFor(data.rol.toLowerCase());

            } catch (err) {
                console.error("Error al conectar al backend:", err);
                loginError.style.display = "block";
            }
        });
    }

    /* ======================================================
         OCULTAR MENÚ SEGÚN EL ROL
    ======================================================= */

    const userRole = localStorage.getItem("komodo_role");

    if (userRole) {
        const btnIngresos = document.querySelector('a[data-menu="ingresos"]');
        const btnSolicitudes = document.querySelector('a[data-menu="solicitudes"]');
        const btnLogoutHeader = document.getElementById("btnLogout");


        // trabajador → solo ve reservas e inventario
        if (userRole === "trabajador") {
            if (btnIngresos) btnIngresos.style.display = "none";
            if (btnSolicitudes) btnSolicitudes.style.display = "none";
            if (btnLogoutHeader) btnLogoutHeader.style.display = "inline-block";

        }
    }

    /* ======================================================
         MOSTRAR/OCULTAR "MIS CITAS"
    ======================================================= */

    const btnMisCitas = document.getElementById("btnMisCitas");

    if (btnMisCitas) {
        const userId = localStorage.getItem("komodo_user_id");
        const userRole = localStorage.getItem("komodo_role"); // ← importante

        // Si NO está logueado → ocultar
        if (!userId) {
            btnMisCitas.style.display = "none";
        }
        // Si está logueado pero NO es cliente → ocultar
        else if (userRole !== "cliente") {
            btnMisCitas.style.display = "none";
        }
        // Si es cliente → mostrar
        else {
            btnMisCitas.style.display = "inline-block";
        }
    }

    // Mostrar/Ocultar botón de Cerrar Sesión en el header del INDEX
    const btnLogoutHeader = document.getElementById("btnLogout");
    if (btnLogoutHeader) {
        const userId = localStorage.getItem("komodo_user_id");

        if (!userId) {
            btnLogoutHeader.style.display = "none";
        } else {
            btnLogoutHeader.style.display = "inline-block";
        }
    }

    /* ======================================================
         SALUDO DEL USUARIO
    ======================================================= */
    const saludo = document.getElementById("saludoUsuario");

    if (saludo) {
        const nombre = localStorage.getItem("komodo_user");
        if (nombre) {
            saludo.textContent = `Hola, ${nombre} 👋`;
        } else {
            saludo.textContent = "";
        }
    }

});

/* =============================
    Cerrar modal
============================= */
document.addEventListener("click", (e) => {
    if (e.target.dataset.close === "authModal") {
        authModal?.close();
    }
});

/* =============================
      Cerrar sesión REAL
============================= */
document.addEventListener("click", (e) => {
    const logoutBtn = e.target.closest("[data-logout]");

    if (logoutBtn) {

        // Borrar sesión
        localStorage.clear();

        // Mensaje flotante
        const msg = document.createElement("div");
        msg.innerHTML = "✔ Sesión cerrada. ¡Hasta pronto!";
        msg.style.position = "fixed";
        msg.style.top = "25px";
        msg.style.right = "25px";
        msg.style.background = "#111";
        msg.style.padding = "14px 22px";
        msg.style.borderRadius = "10px";
        msg.style.border = "1px solid #ffd966";
        msg.style.color = "#ffd966";
        msg.style.fontSize = "16px";
        msg.style.fontWeight = "bold";
        msg.style.boxShadow = "0 6px 20px rgba(0,0,0,.6)";
        msg.style.zIndex = "9999";
        msg.style.opacity = "0";
        msg.style.transition = "opacity .45s ease-out";

        document.body.appendChild(msg);

        // Mostrar mensaje
        setTimeout(() => {
            msg.style.opacity = "1";
        }, 50);

        // Ocultar y redirigir
        setTimeout(() => {
            msg.style.opacity = "0";
            setTimeout(() => {
                window.location.href = "/Komodo/index.html";
            }, 300);
        }, 1500);
    }
});
