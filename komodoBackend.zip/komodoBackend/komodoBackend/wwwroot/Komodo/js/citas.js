﻿// ============================================
//  CITAS.JS — Crear reserva en la base de datos
// ============================================

// --- Enviar correo de confirmación ---
async function enviarConfirmacionCorreo() {

    const templateParams = {
        to_name: state.nombre,
        to_email: state.correo,
        servicio: state.servicio,
        fecha: state.fecha,
        hora: state.hora,
        total: fmtCLP(calcularTotal())
    };

    try {
        const res = await emailjs.send(
            "service_123",          // ← SERVICE ID REAL
            "template_ovmjnro",     // ← TEMPLATE ID REAL
            templateParams
        );

        console.log("Correo enviado ✔️", res);
        setTimeout(() => {
            window.location.href = "/Komodo/index.html";
        }, 1500);

        return true;

    } catch (err) {
        console.error("Error enviando correo:", err);
        return false;
    }
}



// --- Crear cita en backend ---
async function crearCita() {

    // 1. Obtener ID cliente desde sesión REAL
    const idCliente = localStorage.getItem("komodo_user_id");

    // 2. Obtener nombre del servicio desde STATE (cliente.js)
    const servicioNombre = state.servicio;

    // Buscar servicio REAL por ID (lo llenamos en cliente.js)
    const servicio = window.__SERVICIOS_FROM_API__
        ?.find(s =>
            s.nombre_servicio === servicioNombre ||
            s.nombre === servicioNombre
        );

    const idServicio = servicio?.id ?? null;

    // 3. Obtener fecha y hora
    const fecha = document.getElementById("fecha").value;
    const hora = document.getElementById("hora").value;

    console.log("Datos enviados:", {
        idCliente,
        idServicio,
        fecha,
        hora
    });

    // === Validaciones ===
    if (!idCliente) {
        alert("Debes iniciar sesión para reservar.");
        return;
    }

    if (!idServicio || !fecha || !hora) {
        alert("Debe completar servicio, fecha y hora.");
        return;
    }

    const body = {
        id_cliente: parseInt(idCliente),
        id_servicio: parseInt(idServicio),
        fecha,
        hora
    };

    // === Enviar al backend ===
    try {
        const res = await fetch("https://localhost:7216/Citas", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(body)
        });

        if (!res.ok) {
            alert("Error en el servidor (no se pudo crear la cita)");
            return;
        }

        const data = await res.json();

        if (data.ok) {

            alert("Cita creada correctamente 🥳\nID: " + data.id);

            // Guardar fecha/hora en STATE antes del correo
            state.fecha = fecha;
            state.hora = hora;

            // --- Enviar correo ---
            const enviado = await enviarConfirmacionCorreo();

            if (enviado) {
                console.log("Correo enviado después de crear cita.");
            } else {
                console.log("La cita se creó, pero el correo falló.");
            }

        } else {

            alert("Error: " + data.msg);

        }

    } catch (err) {
        console.error("ERROR FETCH:", err);
        alert("No se pudo conectar al servidor.");
    }
}
