/* -------------------------------------------------------
   KÓMODO — RESERVA + CALCULADORA + WEBPAY
------------------------------------------------------- */

/* ====== Estado Global ====== */
const state = {
    cat: "cortes",
    servicio: null,
    totalBase: 0,
    largo: "corto",
    abundancia: "normal",
    historial: "ninguno",
    fecha: "",
    hora: "",
    nombre: "",
    correo: ""
};

const $ = (q, c = document) => c.querySelector(q);

/* ============================================================
   CARGAR SERVICIOS DESDE BACKEND
============================================================ */
window.__SERVICIOS_FROM_API__ = [];

async function loadServiciosFromBackend() {
    try {
        const resp = await fetch("https://localhost:7216/api/Servicios");
        const data = await resp.json();
        window.__SERVICIOS_FROM_API__ = data;
    } catch (e) {
        console.error("Error cargando servicios:", e);
    }
}

/* ============================================================
   RELLENAR SELECT
============================================================ */
function fillServices(cat) {
    const sel = $("#select-servicio");
    sel.innerHTML = "";

    const serviciosCat = window.__SERVICIOS_FROM_API__
        .filter(s => (s.categoria || "").toLowerCase() === cat);

    serviciosCat.forEach(s => {
        const id = s.id_servicio ?? s.id;
        const nombre = s.nombre_servicio ?? s.nombre;
        const precio = s.precio_referencial ?? s.precio;

        const opt = document.createElement("option");
        opt.value = id;
        opt.textContent = `${nombre} — ${fmtCLP(precio)}`;
        sel.appendChild(opt);
    });

    if (serviciosCat.length > 0) {
        const s = serviciosCat[0];
        state.servicio = s.id_servicio ?? s.id;
        state.totalBase = s.precio_referencial ?? s.precio;
    }

    toggleAdvanced();
    updateLiveTotal();
}

/* ============================================================
   UTILIDADES
============================================================ */
const fmtCLP = n =>
    Number(n).toLocaleString("es-CL", { style: "currency", currency: "CLP" });

function isCuts() { return state.cat === "cortes"; }

const AJUSTE_LARGO = { corto: 0, medio: 4000, largo: 8000, extra: 12000 };
const AJUSTE_ABUNDANCIA = { poco: 0, normal: 2000, mucho: 4000 };

function calcularTotal() {
    const servicio = window.__SERVICIOS_FROM_API__.find(
        s => (s.id_servicio ?? s.id) === state.servicio
    );

    if (!servicio) return 0;

    let t = servicio.precio_referencial ?? servicio.precio;

    if (!isCuts()) {
        t += AJUSTE_LARGO[state.largo] || 0;
        t += AJUSTE_ABUNDANCIA[state.abundancia] || 0;
    }

    return t;
}

function updateLiveTotal() {
    const t = calcularTotal();
    $("#live_total").textContent = fmtCLP(t);
    $("#live_total_s2").textContent = fmtCLP(t);
}

/* ============================================================
   EVENTOS PARA SELECCIÓN DE SERVICIO
============================================================ */
document.querySelectorAll('input[name="cat"]').forEach(r => {
    r.addEventListener("change", () => {
        state.cat = r.value;
        fillServices(state.cat);
    });
});

$("#select-servicio").addEventListener("change", evt => {
    const id = Number(evt.target.value);

    const info = window.__SERVICIOS_FROM_API__.find(
        s => (s.id_servicio ?? s.id) === id
    );

    state.servicio = id;
    state.totalBase = info.precio_referencial ?? info.precio;

    updateLiveTotal();
});

/* Campos adicionales */
$("#largo").addEventListener("change", e => {
    state.largo = e.target.value;
    updateLiveTotal();
});

$("#abundancia").addEventListener("change", e => {
    state.abundancia = e.target.value;
    updateLiveTotal();
});

$("#historial").addEventListener("change", e => {
    state.historial = e.target.value;
    updateLiveTotal();
});

const advBox = $("#advancedFactors");

function toggleAdvanced() {
    if (isCuts()) {
        advBox.style.display = "none";
    } else {
        advBox.style.display = "";
    }
}

/* ============================================================
   PASOS DEL FORM
============================================================ */
function moveStep(n) {
    document.querySelectorAll(".steps li").forEach((el, i) => {
        el.classList.toggle("is-active", i === n);
    });
}

$("#toStep2").addEventListener("click", () => {
    $("#step1").classList.remove("is-active");
    $("#step2").classList.add("is-active");
    moveStep(1);
    initNiceCalendar();
});

$("#back1").addEventListener("click", () => {
    $("#step2").classList.remove("is-active");
    $("#step1").classList.add("is-active");
    moveStep(0);
});

$("#toStep3").addEventListener("click", () => {
    if (!state.fecha || !state.hora) return alert("Selecciona fecha y hora");

    state.nombre = $("#nombre").value.trim();
    state.correo = $("#correo").value.trim();

    const servicio = window.__SERVICIOS_FROM_API__.find(
        s => (s.id_servicio ?? s.id) === state.servicio
    );

    $("#r_servicio").textContent = servicio.nombre_servicio ?? servicio.nombre;

    $("#r_largo_li").style.display = isCuts() ? "none" : "";
    $("#r_abun_li").style.display = isCuts() ? "none" : "";
    $("#r_hist_li").style.display = isCuts() ? "none" : "";

    $("#r_largo").textContent = state.largo;
    $("#r_abun").textContent = state.abundancia;
    $("#r_hist").textContent = state.historial;

    $("#r_fecha").textContent = state.fecha;
    $("#r_hora").textContent = state.hora;
    $("#r_total").textContent = fmtCLP(calcularTotal());

    $("#step2").classList.remove("is-active");
    $("#step3").classList.add("is-active");
    moveStep(2);
});

$("#back2").addEventListener("click", () => {
    $("#step3").classList.remove("is-active");
    $("#step2").classList.add("is-active");
    moveStep(1);
});

/* ============================================================
   CALENDARIO
============================================================ */
let calRendered = false;
let currentMonth = new Date().getMonth();
let currentYear = new Date().getFullYear();

function initNiceCalendar() {
    if (calRendered) return;
    calRendered = true;

    const monthNames = [
        "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
        "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
    ];

    const calMonth = $("#calMonth");
    const calYear = $("#calYear");
    const calGrid = $("#calGrid");

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    async function render() {
        calGrid.innerHTML = "";
        calMonth.textContent = monthNames[currentMonth];
        calYear.textContent = currentYear;

        let start = new Date(currentYear, currentMonth, 1).getDay();
        if (start === 0) start = 7;

        for (let i = 1; i < start; i++) {
            const empty = document.createElement("span");
            empty.className = "cal__day cal__day--muted";
            calGrid.appendChild(empty);
        }

        const last = new Date(currentYear, currentMonth + 1, 0).getDate();

        for (let d = 1; d <= last; d++) {
            const btn = document.createElement("button");
            btn.type = "button";
            btn.className = "cal__day";
            btn.textContent = d;

            const dayDate = new Date(currentYear, currentMonth, d);
            dayDate.setHours(0, 0, 0, 0);

            // 🔥 BLOQUEAR DÍAS PASADOS
            if (dayDate < today) {
                btn.disabled = true;
                btn.classList.add("cal__day--disabled");
            }

            btn.onclick = () => {
                if (btn.disabled) return;

                const iso = `${currentYear}-${String(currentMonth + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;

                state.fecha = iso;
                $("#fecha").value = iso;

                document.querySelectorAll(".cal__day")
                    .forEach(x => x.classList.remove("cal__day--selected"));

                btn.classList.add("cal__day--selected");
                loadHours();
            };

            calGrid.appendChild(btn);
        }
    }

    $("#calPrev").onclick = () => {
        currentMonth--;
        if (currentMonth < 0) { currentMonth = 11; currentYear--; }
        render();
    };

    $("#calNext").onclick = () => {
        currentMonth++;
        if (currentMonth > 11) { currentMonth = 0; currentYear++; }
        render();
    };

    /* ============================================================
       HORAS DISPONIBLES (BLOQUEA HORAS YA TOMADAS)
    ============================================================ */
    async function loadHours() {
        const hours = [
            "10:00", "10:30", "11:00", "11:30", "12:00", "12:30",
            "13:00", "15:00", "15:30", "16:00", "16:30",
            "17:00", "17:30", "18:00"
        ];

        const list = $("#timesList");
        list.innerHTML = "";

        if (!state.fecha) return;

        // 🔥 PEDIR HORAS OCUPADAS AL BACKEND
        let horasOcupadas = [];
        try {
            const resp = await fetch(`https://localhost:7216/Reserva/HorasOcupadas?fecha=${state.fecha}`);
            if (resp.ok) horasOcupadas = await resp.json();
        } catch (e) {
            console.error("Error horas ocupadas:", e);
        }

        hours.forEach(h => {
            const btn = document.createElement("button");
            btn.type = "button";
            btn.className = "times__btn";
            btn.textContent = h;

            // 🔥 BLOQUEAR HORA OCUPADA
            if (horasOcupadas.includes(h)) {
                btn.disabled = true;
                btn.classList.add("times__btn--disabled");
            }

            btn.onclick = () => {
                if (btn.disabled) return;

                state.hora = h;
                $("#hora").value = h;

                document.querySelectorAll(".times__btn")
                    .forEach(x => x.classList.remove("times__btn--active"));

                btn.classList.add("times__btn--active");
            };

            list.appendChild(btn);
        });

        $("#timesTitle").textContent = "Selecciona una hora";
    }

    render();
}


/* ============================================================
   BOOTSTRAP
============================================================ */
(async function start() {
    await loadServiciosFromBackend();
    fillServices(state.cat);
    updateLiveTotal();
})();

/* ============================================================
   IR A PAGO
============================================================ */
async function irAPago() {

    state.nombre = $("#nombre").value.trim();
    state.correo = $("#correo").value.trim();

    if (!state.nombre || !state.correo) {
        alert("Debes ingresar nombre y correo.");
        return;
    }

    const servicio = window.__SERVICIOS_FROM_API__.find(
        s => (s.id_servicio ?? s.id) === state.servicio
    );

    if (!servicio) {
        alert("Error encontrando el servicio.");
        return;
    }

    const idCliente = Number(localStorage.getItem("komodo_user_id"));

    if (!idCliente) {
        alert("No se encontró usuario. Inicia sesión.");
        return;
    }

    const respPago = await fetch("https://localhost:7216/Pago/IniciarPago", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            idServicio: servicio.id_servicio ?? servicio.id,
            idCliente,
            fecha: state.fecha,
            hora: state.hora
        })
    });

    const pagoData = await respPago.json();

    if (!respPago.ok) {
        console.error(pagoData);
        alert("Error iniciando el pago.");
        return;
    }

    window.location.href = `${pagoData.url}?token_ws=${pagoData.token}`;
}
