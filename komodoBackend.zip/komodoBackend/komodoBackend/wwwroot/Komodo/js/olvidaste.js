﻿async function enviarReset() {
    const correo = document.getElementById("correo").value;

    if (!correo) {
        alert("Ingresa un correo");
        return;
    }

    // 1. pedir token al backend
    const res = await fetch("https://localhost:7216/Usuario/OlvidarPassword", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(correo)
    });

    if (!res.ok) {
        alert("Correo no encontrado");
        return;
    }

    const data = await res.json();
    const token = data.token;

    // 2. construir link
    const link = `http://localhost:7216/Komodo/restablecer.html?token=${token}`;

    // 3. enviar correo con EmailJS
    emailjs.send("service_123", "template_ovywtnl", {
        to_email: correo,
        name: "KÓMODO",
        to_name: "Usuario",
        reset_link: resetLink
    })

    .then(() => {
        alert("Se ha enviado el enlace para restablecer tu contraseña.");
    }).catch(() => {
        alert("Error enviando el correo");
    });
}
