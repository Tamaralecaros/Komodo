// ==========================================
// INVENTARIO.JS — Conectado al backend real
// ==========================================

const API = "https://localhost:7216/Inventario";
const API_REQ = "https://localhost:7216/Solicitud_Compra";

const $ = (s, c = document) => c.querySelector(s);

let INVENTORY = [];
let filterText = "";

// ==========================================
// BACKEND: INVENTARIO
// ==========================================

async function getInventario() {
    try {
        const resp = await fetch(`${API}/Lista`);
        const data = await resp.json();

        // Tu backend YA devuelve:
        // id, name, category, stock, min, unit, updated
        return data;
    } catch (err) {
        console.error(err);
        alert("No se pudo conectar al backend.");
        return [];
    }
}

async function crearProducto(data) {
    await fetch(`${API}/Crear`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    });
}

async function editarProducto(id, data) {
    await fetch(`${API}/Editar/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    });
}

async function eliminarProducto(id) {
    await fetch(`${API}/Eliminar/${id}`, { method: "DELETE" });
}

// ==========================================
// BACKEND: SOLICITUDES
// ==========================================

async function solicitarProducto(id, qty, note) {
    const usuario = localStorage.getItem("nombreUsuario") || "Usuario";

    const payload = {
        id_producto: Number(id),
        cantidad: Number(qty),
        nota: note || "",
        usuario: usuario
    };

    try {
        const resp = await fetch(`${API_REQ}/Crear`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        if (!resp.ok) throw new Error();
        alert("✔ Tu solicitud fue enviada correctamente.");
    } catch (err) {
        alert("❌ No se pudo enviar la solicitud.");
        console.error(err);
    }
}

async function getSolicitudes() {
    try {
        const resp = await fetch(`${API_REQ}/Lista`);
        return await resp.json();
    } catch (err) {
        console.error(err);
        return [];
    }
}

// ==========================================
// RENDER INVENTARIO
// ==========================================

function render() {
    const rows = INVENTORY
        .filter(p => p.name && p.name.toLowerCase().includes(filterText.toLowerCase()))
        .map(productRow)
        .join("");

    const tblBody = $("#invTable tbody");
    tblBody.innerHTML = rows || `<tr><td colspan="8" class="muted">No hay resultados</td></tr>`;
}

function productRow(p) {
    const badge = p.stock <= 0 ? "badge--out"
        : p.stock <= p.min ? "badge--low"
            : "badge--ok";

    const txt = p.stock <= 0 ? "Sin stock"
        : p.stock <= p.min ? "Bajo"
            : "OK";

    return `
    <tr data-id="${p.id}">
        <td>${p.name}</td>
        <td>${p.category || "-"}</td>
        <td>${p.stock}</td>
        <td>${p.min}</td>
        <td>${p.unit}</td>
        <td><span class="badge ${badge}">${txt}</span></td>
        <td>${p.updated}</td>
        <td>
            <button class="btn btn--ghost" data-edit>Editar</button>
            <button class="btn btn--ghost" data-request>Solicitar</button>
            <button class="btn btn--gold" data-delete>Eliminar</button>
        </td>
    </tr>`;
}

// ==========================================
// EVENTOS TABLA
// ==========================================

function setupTableEvents() {
    const tblBody = $("#invTable tbody");

    tblBody.addEventListener("click", (e) => {
        const tr = e.target.closest("tr[data-id]");
        if (!tr) return;

        const id = tr.dataset.id;

        if (e.target.matches("[data-edit]")) openEdit(id);
        if (e.target.matches("[data-delete]")) removeProduct(id);
        if (e.target.matches("[data-request]")) openRequest(id);
    });
}

// ==========================================
// CRUD PRODUCTOS
// ==========================================

function setupCRUD() {
    const btnAdd = $("#btnAddProduct");
    const productForm = $("#productForm");
    const modalProduct = $("#modalProduct");

    btnAdd.addEventListener("click", () => {
        productForm.reset();
        productForm.elements.id.value = "";
        $("#modalProductTitle").textContent = "Nuevo producto";
        modalProduct.showModal();
    });

    productForm.addEventListener("submit", async e => {
        e.preventDefault();

        const data = Object.fromEntries(new FormData(productForm));

        const payload = {
            name: data.name,
            category: data.category,
            stock: Number(data.stock),
            min: Number(data.min),
            unit: data.unit
        };

        if (data.id) {
            await editarProducto(data.id, payload);
        } else {
            await crearProducto(payload);
        }

        modalProduct.close();
        INVENTORY = await getInventario();
        render();
    });
}

function openEdit(id) {
    const p = INVENTORY.find(x => x.id == id);
    if (!p) return;

    const productForm = $("#productForm");
    productForm.reset();

    $("#modalProductTitle").textContent = "Editar producto";

    productForm.elements.id.value = p.id;
    productForm.elements.name.value = p.name;
    productForm.elements.category.value = p.category;
    productForm.elements.stock.value = p.stock;
    productForm.elements.min.value = p.min;
    productForm.elements.unit.value = p.unit;

    $("#modalProduct").showModal();
}

async function removeProduct(id) {
    if (!confirm("¿Eliminar producto?")) return;
    await eliminarProducto(id);
    INVENTORY = await getInventario();
    render();
}

// ==========================================
// SOLICITAR PRODUCTO
// ==========================================

function setupSolicitudes() {
    const btnReqs = $("#btnViewRequests");
    const requestForm = $("#requestForm");
    const modalRequest = $("#modalRequest");
    const modalList = $("#modalRequestsList");
    const requestsContainer = $("#requestsContainer");

    btnReqs.addEventListener("click", async () => {
        const solicitudes = await getSolicitudes();

        if (!solicitudes.length) {
            requestsContainer.innerHTML = `<p class="muted">No hay solicitudes.</p>`;
        } else {
            requestsContainer.innerHTML = solicitudes.map(s => `
                <div class="req-item">
                    <strong>${s.producto}</strong>
                    <div class="req-item__meta">Peluquero: ${s.peluquero}</div>
                    <div class="req-item__meta">Cantidad: ${s.cantidad}</div>
                    <div class="req-item__meta">Nota: ${s.nota || "-"}</div>
                    <div class="req-item__meta">Fecha: ${s.fecha}</div>
                    <div class="req-item__meta">Estado: ${s.estado}</div>
                </div>
            `).join("");
        }

        modalList.showModal();
    });

    requestForm.addEventListener("submit", async e => {
        e.preventDefault();
        const data = Object.fromEntries(new FormData(requestForm));
        await solicitarProducto(data.id, data.qty, data.note);
        modalRequest.close();
    });
}

function openRequest(id) {
    const p = INVENTORY.find(x => x.id == id);
    const requestForm = $("#requestForm");

    requestForm.reset();
    requestForm.elements.id.value = id;

    $("#reqProductLabel").textContent = `Producto: ${p.name}`;

    $("#modalRequest").showModal();
}

// ==========================================
// INIT
// ==========================================

document.addEventListener("DOMContentLoaded", async () => {
    setupTableEvents();
    setupCRUD();
    setupSolicitudes();

    INVENTORY = await getInventario();
    render();
});
