﻿// =========================
// INGRESOS.JS — Panel admin
// =========================

async function cargarIngresos() {
    try {
        // 1) RESUMEN
        const resResumen = await fetch("https://localhost:7216/Ingresos/Resumen");
        const resumen = await resResumen.json();

        document.querySelector("#k_today_amount").textContent = `$${resumen.hoy}`;
        document.querySelector("#k_today_count").textContent = `${resumen.hoyCount} pagos`;

        document.querySelector("#k_week_amount").textContent = `$${resumen.semana}`;
        document.querySelector("#k_week_count").textContent = `${resumen.semanaCount} pagos`;

        document.querySelector("#k_month_amount").textContent = `$${resumen.mes}`;
        document.querySelector("#k_month_count").textContent = `${resumen.mesCount} pagos`;

        document.querySelector("#k_total_amount").textContent = `$${resumen.total}`;
        document.querySelector("#k_total_count").textContent = `${resumen.totalCount} pagos`;


        // 2) MOVIMIENTOS
        const resMov = await fetch("https://localhost:7216/Ingresos/Movimientos");
        const movimientos = await resMov.json();

        const tbody = document.querySelector("#tbody_ingresos");
        tbody.innerHTML = "";

        movimientos.forEach(mov => {
            const fecha = new Date(mov.fecha).toLocaleDateString();

            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td>${fecha}</td>
                <td>${mov.cliente}</td>
                <td>${mov.servicio}</td>
                <td>${mov.metodo}</td>
                <td class="ta-r">$${mov.monto}</td>
            `;
            tbody.appendChild(tr);
        });

    } catch (err) {
        console.error("Error cargando ingresos:", err);
    }
}

document.addEventListener("DOMContentLoaded", cargarIngresos);
