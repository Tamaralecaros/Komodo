﻿async function cambiarPassword() {
    const params = new URLSearchParams(window.location.search);
    const token = params.get("token");

    const nueva = document.getElementById("pass").value;

    if (!nueva) {
        alert("Ingresa una contraseña");
        return;
    }

    const res = await fetch("https://localhost:7216/Usuario/ResetPassword", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: token, password: nueva })
    });

    const data = await res.json();
    alert(data.message);
}
