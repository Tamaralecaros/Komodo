/* roles.js — control real de sesión */

export const ROLES = {
    CLIENTE: "cliente",
    TRABAJADOR: "trabajador",
    ADMIN: "admin"
};

const STORAGE_ROLE = "komodo_role";
const STORAGE_USER = "komodo_user";
const STORAGE_ID = "komodo_user_id";

/* Guarda sesión completa */
export function setSession({ id, nombre, rol }) {
    localStorage.setItem(STORAGE_ID, id);
    localStorage.setItem(STORAGE_USER, nombre);
    localStorage.setItem(STORAGE_ROLE, rol);
}

/* Obtener datos */
export function getRole() {
    return localStorage.getItem(STORAGE_ROLE);
}

export function getUser() {
    return localStorage.getItem(STORAGE_USER);
}

export function getUserId() {
    return Number(localStorage.getItem(STORAGE_ID));
}

/* Cerrar sesión */
export function clearSession() {
    localStorage.removeItem(STORAGE_ID);
    localStorage.removeItem(STORAGE_USER);
    localStorage.removeItem(STORAGE_ROLE);
}

/* Proteger vistas (admin, trabajador, etc.) */
export function guard(allowed = [], onDeny = "/Komodo/index.html") {
    const r = getRole();
    if (!r || !allowed.includes(r)) {
        location.href = onDeny;
    }
}

/* Adaptar header (si alguna página lo usa) */
export function adaptHeader() {
    const role = getRole();
    document.querySelectorAll("[data-role-show]").forEach(el => {
        const allow = (el.dataset.roleShow || "").split(",");
        el.style.display = allow.includes(role) ? "" : "none";
    });
}

/* Home según rol */
export function homeFor(role) {
    if (role === ROLES.ADMIN) return "/Komodo/vista_ingresos.html";
    if (role === ROLES.TRABAJADOR) return "/Komodo/vista_reservas.html?mine=1";
    return "/Komodo/cliente.html";
}

/* =====================================================
   NUEVO: OCULTAR TABS SEGÚN ROL (para trabajador)
===================================================== */

export function applyTabVisibility() {
    const rol = getRole();
    if (!rol) return;

    // Selección de tabs
    const tabIngresos = document.querySelector('a[href="/Komodo/vista_ingresos.html"]');
    const tabSolicitudes = document.querySelector('a[href="/Komodo/vista_solicitudes.html"]');

    // Si es TRABAJADOR → ocultar Ingresos + Solicitudes
    if (rol === ROLES.TRABAJADOR) {
        tabIngresos?.remove();
        tabSolicitudes?.remove();
    }

    // CLIENTE nunca debería ver estas páginas, pero por si acaso
    if (rol === ROLES.CLIENTE) {
        tabIngresos?.remove();
        tabSolicitudes?.remove();
    }
}
