/* ===========================================================
   ADMIN · KÓMODO  — CONECTADO AL BACKEND REAL
   - KPIs: #k_today_amount, #k_week_amount, #k_month_amount, #k_total_amount
   - Tabla: #tbl_mov
   - Backend: GET https://localhost:7216/Pago/Ingresos
=========================================================== */

// Utils
const $ = (s, c = document) => c.querySelector(s);
const CL = (n) => document.createElement(n);
const fmtCLP = (n) => `$${(Number(n) || 0).toLocaleString('es-CL')}`;

// ========================== 1) GET INGRESOS ==========================
async function getIngresosFromBackend() {
    try {
        const url = "https://localhost:7216/Pago/Ingresos";
        const resp = await fetch(url);

        if (!resp.ok) {
            console.error("Error al obtener ingresos:", resp.statusText);
            return [];
        }

        const data = await resp.json();
        return Array.isArray(data) ? data : [];

    } catch (err) {
        console.error("Fallo conexión backend:", err);
        return [];
    }
}

// ========================== 2) KPIs ==========================
function paintKPIs(list) {
    const num = x => Number(x) || 0;

    const sum = list.reduce((a, x) => a + num(x.monto), 0);
    const count = list.length;

    // HOY
    const hoy = new Date().toLocaleDateString("es-CL");
    const hoyList = list.filter(m => new Date(m.fecha).toLocaleDateString("es-CL") === hoy);
    const hoyMonto = hoyList.reduce((a, x) => a + num(x.monto), 0);

    $("#k_today_amount").textContent = fmtCLP(hoyMonto);
    $("#k_today_count").textContent = `${hoyList.length} pagos`;

    // SEMANA
    const now = new Date();
    const weekCut = new Date(now);
    weekCut.setDate(now.getDate() - 7);

    const weekList = list.filter(x => new Date(x.fecha) >= weekCut);
    const weekMonto = weekList.reduce((a, x) => a + num(x.monto), 0);

    $("#k_week_amount").textContent = fmtCLP(weekMonto);
    $("#k_week_count").textContent = `${weekList.length} pagos`;

    // MES
    const month = now.getMonth();
    const year = now.getFullYear();

    const monthList = list.filter(x => {
        const d = new Date(x.fecha);
        return d.getMonth() === month && d.getFullYear() === year;
    });

    const monthMonto = monthList.reduce((a, x) => a + num(x.monto), 0);

    $("#k_month_amount").textContent = fmtCLP(monthMonto);
    $("#k_month_count").textContent = `${monthList.length} pagos`;

    // TOTAL
    $("#k_total_amount").textContent = fmtCLP(sum);
    $("#k_total_count").textContent = `${count} pagos`;
}

// ========================== 3) TABLA ==========================
function rowHTML(m, i) {
    const fechaTxt = new Date(m.fecha).toLocaleDateString("es-CL");
    return `
    <tr>
      <td>${fechaTxt}</td>
      <td>${m.cliente}</td>
      <td>${m.servicio}</td>
      <td>${m.metodo}</td>
      <td class="ta-r">${fmtCLP(m.monto)}</td>
      <td>#</td>
    </tr>
  `;
}

function paintTable(list) {
    const tbody = document.querySelector("#tbl_mov tbody");
    if (!tbody) return;

    if (!list.length) {
        tbody.innerHTML = `<tr><td colspan="6" class="muted">Sin movimientos registrados</td></tr>`;
        return;
    }

    tbody.innerHTML = list.map(rowHTML).join("");
}

// ========================== 4) INIT ==========================
async function cargarDashboard() {
    const ingresos = await getIngresosFromBackend();
    paintKPIs(ingresos);
    paintTable(ingresos);
}

document.addEventListener("DOMContentLoaded", cargarDashboard);
