﻿document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("formCotizacion");

    form.addEventListener("submit", function (e) {
        e.preventDefault();

        // datos del formulario
        const nombre = document.getElementById("nombre").value;
        const correo = document.getElementById("correo").value;
        const servicio = document.getElementById("servicio").value;
        const largo = document.getElementById("largo").value;
        const abundancia = document.getElementById("abundancia").value;
        const total = document.getElementById("total").textContent;

        const params = {
            to_name: "Administrador KÓMODO",
            servicio: servicio,
            fecha: new Date().toLocaleDateString(),
            hora: new Date().toLocaleTimeString(),
            total: total,
            mensaje: `Cotización enviada por: ${nombre} (${correo})  
                      Servicio: ${servicio}
                      Largo: ${largo}
                      Abundancia: ${abundancia}
                      Total estimado: ${total}`
        };

        emailjs.send("service_123", "template_ovmjnro", params, "wJn2iMQKwXdMDtvqH")
            .then(() => {
                document.getElementById("mensajeStatus").textContent =
                    "Cotización enviada correctamente. Te contactaremos dentro de los próximos 3 días hábiles.";
                form.reset();
            })
            .catch((err) => {
                console.error("Error enviando cotización:", err);
                alert("Hubo un error al enviar la cotización.");
            });

    });
});
