﻿using komodoBackend.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// ============================================
// 1) REGISTRO DE SERVICIOS (ANTES DE BUILD)
// ============================================

builder.Services.AddDbContext<KomodoContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("KomodoConnection")));

builder.Services.AddControllersWithViews();

// 👇 Necesario para usar HttpContext.Session
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
});

// ============================================
// 2) CONSTRUIR LA APLICACIÓN
// ============================================

var app = builder.Build();

// ============================================
// 3) MIDDLEWARES (DESPUÉS DEL BUILD)
// ============================================

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

// 👇 Session debe ir DESPUÉS de UseRouting y ANTES de MapControllerRoute
app.UseSession();

// ============================================
// 4) RUTA PRINCIPAL
// ============================================

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
