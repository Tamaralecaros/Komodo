﻿using Microsoft.EntityFrameworkCore;

namespace komodoBackend.Models
{
    public class KomodoContext : DbContext
    {
        public KomodoContext(DbContextOptions<KomodoContext> options)
            : base(options)
        {
        }

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Servicio> Servicios { get; set; }
        public DbSet<Pago> Pagos { get; set; }
        public DbSet<Inventario> Inventarios { get; set; }
        public DbSet<Cita> Citas { get; set; }
        public DbSet<Reporte> Reportes { get; set; }
        public DbSet<Solicitud_Compra> SolicitudesCompra { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Usuario>().ToTable("Usuario");
            modelBuilder.Entity<Servicio>().ToTable("Servicio");
            modelBuilder.Entity<Pago>().ToTable("Pago");
            modelBuilder.Entity<Inventario>().ToTable("Inventario");
            modelBuilder.Entity<Cita>().ToTable("Cita");
            modelBuilder.Entity<Reporte>().ToTable("Reporte");
            modelBuilder.Entity<Solicitud_Compra>().ToTable("Solicitud_Compra");
        }
    }
}
