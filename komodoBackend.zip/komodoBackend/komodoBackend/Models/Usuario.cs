﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace komodoBackend.Models
{
    [Table("Usuario")]

    public class Usuario
    {
        [Key]
        public int id_usuario { get; set; }

        public string nombre { get; set; }
        public string correo { get; set; }
        public string? telefono { get; set; }
        public string? rol { get; set; }
        public string contrasena { get; set; }
        public string? resetToken { get; set; }
        public DateTime? tokenExpira { get; set; }

    }
}
