﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace komodoBackend.Models
{
    [Table("Servicio")]
    public class Servicio
    {
        [Key]
        public int id_servicio { get; set; }

        public string nombre_servicio { get; set; }
        public string? descripcion { get; set; }
        public decimal precio_referencial { get; set; }

        public string categoria { get; set; }
    }
}
