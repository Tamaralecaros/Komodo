﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace komodoBackend.Models
{
    [Table("Reporte")]

    public class Reporte
    {
        [Key]
        public int id_reporte { get; set; }

        public DateTime? fecha_inicio { get; set; }
        public DateTime? fecha_fin { get; set; }
        public decimal? total_ingresos { get; set; }
    }
}
