﻿using System;
using System.ComponentModel.DataAnnotations;

namespace komodoBackend.Models
{
    public class Solicitud_Compra
    {
        [Key]
        public int id_solicitud { get; set; }

        public int id_producto { get; set; }
        public int id_peluquero { get; set; }

        public int cantidad { get; set; }   // NUEVO
        public string nota { get; set; }    // NUEVO

        public DateTime fecha_solicitud { get; set; }
        public string estado { get; set; }
    }
}
