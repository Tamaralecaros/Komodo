﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace komodoBackend.Models
{
    [Table("Inventario")]
    public class Inventario
    {
        [Key]
        public int id_producto { get; set; }

        public string? nombre { get; set; }
        public int? cantidad { get; set; }
        public decimal? precio_unitario { get; set; }

        // NUEVOS CAMPOS QUE EXISTEN EN SQL
        public string? categoria { get; set; }
        public int stock_minimo { get; set; }
        public string? unidad { get; set; }
        public DateTime? fecha_actualizacion { get; set; }
    }
}
