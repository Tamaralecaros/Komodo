﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace komodoBackend.Models
{
    [Table("Pago")]
    public class Pago
    {
        [Key]
        public int id_pago { get; set; }

        public int id_cita { get; set; }

        public string? tipo_pago { get; set; }
        public decimal monto { get; set; }
        public DateTime? fecha_pago { get; set; }

        // 🔥 Navegación hacia Cita (NECESARIO para el dashboard)
        [ForeignKey("id_cita")]
        public Cita Cita { get; set; }
    }
}
