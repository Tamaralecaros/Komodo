﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace komodoBackend.Models
{
    [Table("Cita")]
    public class Cita
    {
        [Key]
        public int id_cita { get; set; }

        public int id_cliente { get; set; }
        public int id_servicio { get; set; }

        public DateTime fecha { get; set; }
        public TimeSpan hora { get; set; }
        public string? estado { get; set; }

        [ForeignKey("id_cliente")]
        public Usuario Cliente { get; set; }

        [ForeignKey("id_servicio")]
        public Servicio Servicio { get; set; }
    }
}
